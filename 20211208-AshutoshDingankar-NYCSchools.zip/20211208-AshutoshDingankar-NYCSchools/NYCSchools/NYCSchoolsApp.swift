//
//  NYCSchoolsApp.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import SwiftUI

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        //Fetching SAT scores during the app launch
        StartupServices.shared.fetchSATResults()
        
        return true
    }
}

@main
struct NYCSchoolsApp: App {
    //This is required to get access to AppDelegate methods
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            SchoolListView()
        }
    }
}
