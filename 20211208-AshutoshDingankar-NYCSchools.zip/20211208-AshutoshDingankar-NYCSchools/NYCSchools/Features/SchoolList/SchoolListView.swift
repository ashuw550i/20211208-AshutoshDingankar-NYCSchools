//
//  SchoolListView.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import SwiftUI

struct SchoolListView: View {
    @StateObject private var viewModel = SchoolListViewModel()
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            VStack {
                header
                switch viewModel.loadingState {
                case .loaded:
                    if viewModel.schools.count > 0 {
                        schoolList
                    } else {
                        Spacer()
                        EmptyStateView(title: Constants.NO_RESULTS)
                        Spacer()
                    }
                case .error:
                    Spacer()
                    EmptyStateView(title: Constants.GENERIC_ERROR_MESSAGE)
                    Spacer()
                default:
                    Spacer()
                    progressView
                    Spacer()
                }
            }
            .onAppear {
                viewModel.fetchSchools()
            }
            .navigationBarTitle(Text(Constants.NYCSchools))
        }
    }
    
    private var header: some View {
        VStack(spacing: 8) {
            SearchBar(text: $searchText)
        }
        .padding(.horizontal, 16)
    }
    
    private var schoolList: some View {
        ScrollView {
            let schools = viewModel.schools.filter({ searchText.isEmpty ? true : $0.school_name?.contains(searchText) ?? false })
            ForEach(schools, id: \.self) { school in
                NavigationLink(destination: SchoolDetailsView(school: school)) {
                    VStack(spacing: 0.0) {
                        ListItemView(title: school.name) {
                            ChevronControl()
                        }
                    }
                }
                .buttonStyle(NavigationLinkStyle())
            }
        }
    }
    
    private var progressView: some View {
        HStack {
            ProgressView()
                .scaleEffect(2, anchor: .center)
        }
        .frame(maxWidth: .infinity)
    }
}

struct SchoolListView_Previews: PreviewProvider {
    static var previews: some View {
        SchoolListView()
    }
}
