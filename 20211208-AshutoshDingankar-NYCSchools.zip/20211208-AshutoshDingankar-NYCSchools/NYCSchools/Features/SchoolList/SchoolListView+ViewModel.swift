//
//  SchoolListViewModel.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import Foundation

enum LoadingState {
    case loading
    case error
    case loaded
}

class SchoolListViewModel: ObservableObject {
    @Published var schools = [School]()
    @Published var loadingState: LoadingState = .loading
    
    func fetchSchools() {
        let schoolsRepository = SchoolsDataRepository(dataSource: SchoolsRemoteDataSource())
        schoolsRepository.getSchools { schools, error in
            if error != nil {
                self.loadingState = .error
                return
            }
            
            if schools != nil {
                self.loadingState = .loaded
                self.schools = schools ?? []
            }
        }        
    }
}
