//
//  SchoolDetailsView.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import SwiftUI

struct SchoolDetailsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var school: School

    var body: some View {
        VStack {
            ScrollView {
                VStack(spacing: 16) {
                    Group {
                        header
                        ContactButtonGroup(school: school)
                        GeneralInformationGroup(school: school)
                        SATScoresGroup(school: school)
                    }
                    .padding(.horizontal, 16)
                }
            }
        }
    }
    
    private var header: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                BackButton {
                    presentationMode.wrappedValue.dismiss()
                }
                Spacer()
                EmptyView()
            }
            .frame(height: 48)
            
            Text(school.name)
                .padding(.vertical, 2)
                .foregroundColor(.black)
                .font(.nycFont(weight: .semibold, size: 20))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 16)
            
            if let website = school.website {
                if let destination = website.prefixHttp(), let url = URL(string: destination) {
                    Link(destination: url) {
                        Text(website)
                            .font(.nycFont(weight: .semibold, size: 15))
                            .padding(.vertical, 4)
                    }
                } else {
                    Text(website)
                        .font(.nycFont(weight: .semibold, size: 15))
                        .padding(.vertical, 4)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .navigationBarTitle("")
        .navigationBarHidden(true)
    }
}

private struct ContactButtonView: View {
    var label: String
    var systemIconName: String
    var action: () -> Void
    
    var body: some View {
        Button(action: action) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.navy900.opacity(0.04))
                VStack(spacing: 8) {
                    Image(systemName: systemIconName)
                        .font(.system(size: 16))
                    Text(label)
                        .font(.nycFont(weight: .semibold, size: 12))
                }
            }
            .frame(width: 76, height: 68, alignment: .center)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

private struct ContactButtonGroup: View {
    var school: School
    
    var body: some View {
        VStack(alignment: .center, spacing: 20) {
            HStack(spacing: 12) {
                if let phone = school.phone {
                    ContactButtonView(label: Constants.CALL,
                                      systemIconName: "phone.fill",
                                      action: {
                                        if let url = URL(string: "tel:\(phone)") {
                                            UIApplication.shared.open(url)
                                        }
                                      })
                }
                
                if let email = school.email {
                    ContactButtonView(label: Constants.EMAIL,
                                      systemIconName: "envelope.fill",
                                      action: {
                                        if let url = URL(string: "mailto:\(email)") {
                                            UIApplication.shared.open(url)
                                        }
                                      })
                }
            }
        
        }
        .padding(.horizontal, 16)
    }
}

private struct GeneralInformationGroup: View {
    var school: School

    var body: some View {
        CardView {
            VStack {
                if let phone = school.phone {
                    ListItemView(title: Constants.PHONE_CELL, description: phone, hasDivider: true)
                }
                if let fax = school.fax {
                    ListItemView(title: Constants.FAX, description: fax, hasDivider: true)
                }
                if let email = school.email {
                    ListItemView(title: Constants.EMAIL, description: email, hasDivider: true)
                }
                //TODO: Somehow address is truncating in the UI. Setting Min-Height=40 inside ListItemView, fixes the issue but UI doesn't look good. Need more time to look into this issue.
                if let address = school.address {
                    ListItemView(title: Constants.ADDRESS, description: address, hasDivider: true)
                }
                if let totalStudents = school.totalStudents {
                    ListItemView(title: Constants.TOTAL_STUDENTS, description: totalStudents, hasDivider: false)
                }
            }
        }
    }
}

private struct SATScoresGroup: View {
    var school: School
    
    var body: some View {
        VStack {
            Text(Constants.SAT_SCORES)
                .font(.nycDisplayFont(size: 15))
                .padding(.leading, 16.0)
            
            CardView {
                VStack {
                    if let dbn = school.dbn {
                        let result = UserStore.shared.getSATResult()
                        
                        ListItemView(title: Constants.MATH_SCORE,
                                     description: result.getMathScore(school: dbn) ?? Constants.NOT_AVAILABLE,
                                     hasDivider: true)
                        
                        ListItemView(title: Constants.READING_SCORE,
                                     description: result.getReadingScore(school: dbn) ?? Constants.NOT_AVAILABLE,
                                     hasDivider: true)
                        
                        ListItemView(title: Constants.WRITING_SCORE,
                                     description: result.getWritingScore(school: dbn) ?? Constants.NOT_AVAILABLE,
                                     hasDivider: false)
                    }
                }
            }
        }
    }
}

struct SchoolDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        SchoolDetailsView(school: School())
    }
}
