//
//  FontConfig.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/05/21.
//


import Foundation
import SwiftUI

extension Font {
    static var trendaDisplaySemibold: String {
        "TrendaDisplay-Semibold"
    }
    
    static var trendaTextRegular: String {
        "TrendaText-Regular"
    }
    
    static var trendaTextSemibold: String {
        "TrendaText-Semibold"
    }
    
    static var trendaTextbold: String {
        "TrendaText-Bold"
    }

    static func nycDisplayFont (size: CGFloat) -> Font {
        return .custom(Font.trendaDisplaySemibold, size: size)
    }
    
    static func nycFont (weight: Font.Weight, size: CGFloat) -> Font {
        switch weight {
        case .semibold, .heavy:
            return .custom(Font.trendaTextSemibold, size: size)
        case .bold:
            return .custom(Font.trendaTextbold, size: size)
        default:
            return .custom(Font.trendaTextRegular, size: size)
        }
    }
}
