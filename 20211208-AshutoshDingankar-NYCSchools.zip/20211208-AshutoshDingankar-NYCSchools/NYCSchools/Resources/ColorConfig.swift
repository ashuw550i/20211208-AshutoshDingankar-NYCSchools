//
//  ColorConfig.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/05/21.
//

import Foundation
import SwiftUI

extension Color {
    /*
     Hex: #00283c
     R:0
     G:40
     B:60
    */
    static var navy900: Color {
        Color("navy900")
    }
    
    static var solidFontOpacity: Double {
        0.87
    }
    
    static var fadedFontOpacity: Double {
        0.6
    }

    static var darkButtonPressedBackgroundOpacity: Double {
        0.16
    }
}
