//
//  StartupServices.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import Foundation

/**
    All the startup services needs to be defined here. I am making SAT scores call during app launch
*/

class StartupServices {
    //Singleton class
    static let shared = StartupServices()
    
    private init() { }
    
    func fetchSATResults() {
        let schoolsRepository = SchoolsDataRepository(dataSource: SchoolsRemoteDataSource())
        schoolsRepository.getSATResults { satScores, error in
            if error != nil {
                return
            }
            

            //Converting array of SatScores into Hashmap -> {dbn:SatScore}. This is for faster lookup O(1), while fetching score data on Details Page. Also, storing the result in common UserStore.
            if let satScores = satScores, satScores.count > 0 {
                let dict = satScores.reduce(into: [String: SATScores]()) {
                    if let dbn = $1.dbn {
                        $0[dbn] = $1
                    }
                }
                
                UserStore.shared.updateSATResult(satResult: dict)
            }
        }
    }
}
