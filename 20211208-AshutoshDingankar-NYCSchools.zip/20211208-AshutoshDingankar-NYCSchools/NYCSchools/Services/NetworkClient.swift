//
//  NetworkClient.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import Foundation
import Alamofire

/**
    Common place to interact with network layer using Alamofire.
*/

class NetworkClient {
    static func getArray<T>(urlString: String, completionHandler: @escaping ([T]?, Error?) -> Void) where T: Codable {
        AF.request(urlString)
            .validate()
            .responseDecodable(of: [T].self) { (response) in
                switch response.result {
                case .success(let data):
                    completionHandler(data, nil)
                    
                case .failure(let error):
                    completionHandler(nil, error)
                }
            }
    }
}
