//
//  SchoolService.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//
 
import Foundation

/**
    Repositoy Pattern to implement Service Layer
*/

public protocol SchoolsRepository {
    func getSchools(_ completionHandler: @escaping ([School]?, Error?) -> Void)
    func getSATResults(_ completionHandler: @escaping ([SATScores]?, Error?) -> Void)
}

public class SchoolsDataRepository {
    private let dataSource: SchoolsDataSource
    
    //Loose coupling. Dependency inversion principle
    public init(dataSource: SchoolsDataSource) {
        self.dataSource = dataSource
    }
    
    public func getSchools(_ completionHandler: @escaping ([School]?, Error?) -> Void) {
        return dataSource.getSchools(completionHandler)
    }

    public func getSATResults(_ completionHandler: @escaping ([SATScores]?, Error?) -> Void) {
        return dataSource.getSATResults(completionHandler)
    }
}

public protocol SchoolsDataSource {
    func getSchools(_ completionHandler: @escaping ([School]?, Error?) -> Void)
    func getSATResults(_ completionHandler: @escaping ([SATScores]?, Error?) -> Void)
}

//This class is reponsible to fetch data from extenal service
public struct SchoolsRemoteDataSource: SchoolsDataSource {
    public func getSchools(_ completionHandler: @escaping ([School]?, Error?) -> Void) {
        let url = "https://data.cityofnewyork.us/resource/s3k6-pzi2.json"
        NetworkClient.getArray(urlString: url, completionHandler: completionHandler)
    }
    
    public func getSATResults(_ completionHandler: @escaping ([SATScores]?, Error?) -> Void) {
        let url = "https://data.cityofnewyork.us/resource/f9bf-2cp4.json"
        NetworkClient.getArray(urlString: url, completionHandler: completionHandler)
    }
}

//This class is reponsible to fetch data from mock data. This is useful for Unit testing the app
public struct SchoolsMockDataSource: SchoolsDataSource {
    public func getSchools(_ completionHandler: @escaping ([School]?, Error?) -> Void) {
        
    }
    
    public func getSATResults(_ completionHandler: @escaping ([SATScores]?, Error?) -> Void) {
        
    }
}
