//
//  Strings.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import Foundation

struct Constants {
    static let PHONE_CELL = "Phone (C)"
    static let FAX = "Fax"
    static let EMAIL = "Email"
    static let ADDRESS = "Address"
    static let SAT_SCORES = "SAT Scores"
    static let MATH_SCORE = "Math"
    static let READING_SCORE = "Reading"
    static let WRITING_SCORE = "Writing"
    static let GENERIC_ERROR_MESSAGE = "Something went wrong."
    static let NO_RESULTS = "No results found."
    static let SEARCH = "Search..."
    static let CANCEL = "Cancel"
    static let CALL = "Call"
    static let NYCSchools = "NYC Schools"
    static let NAME = "Name"
    static let TOTAL_STUDENTS = "Total Students"
    static let NOT_AVAILABLE = "NA"
    static let WEBSITE = "Website"
}
