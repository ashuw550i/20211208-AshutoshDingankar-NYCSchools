//
//  UserStore.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import Foundation

/**
    Shared data resides here.
 */

class UserStore {
    //Singleton class
    static let shared = UserStore()
    private var satResult = SATResult()
    private init() { }
    
    func updateSATResult(satResult: [String: SATScores]) {
        self.satResult.result = satResult
    }
    
    func getSATResult() -> SATResult {
        return self.satResult
    }
}
