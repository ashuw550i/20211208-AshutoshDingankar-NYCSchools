//
//  String+Extensions.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/8/21.
//

import Foundation

extension String {
    
    /**
     Function to return string between "from" & "to" bounds.
     for eg:
     input = "10 East 15th Street, Manhattan NY 10003 (40.736526, -73.992727)"
     from = "("
     to = ")"
     output = 40.736526, -73.992727
    */
    
    func slice(from: String, to: String) -> String? {
        return (range(of: from)?.upperBound).flatMap { substringFrom in
            (range(of: to, range: substringFrom..<endIndex)?.lowerBound).map { substringTo in
                String(self[substringFrom..<substringTo])
            }
        }
    }
    
    //Function to prepend http to the given string
    func prefixHttp() -> String? {
        var urlComponents = URLComponents(string: self)
        if urlComponents?.scheme == nil { urlComponents?.scheme = "http" }
        return urlComponents?.url?.absoluteString
    }
}
