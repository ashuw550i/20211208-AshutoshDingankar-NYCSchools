//
//  Controls.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/5/21.
//

import SwiftUI

struct ChevronControl: View {
    var body: some View {
        Image(systemName: "chevron.right")
            .padding(.trailing, 4.0)
            .opacity(Color.fadedFontOpacity)
    }
}

struct BackButton: View {
    var action: ()->Void
    var body: some View {
        Button(action: {
            action()
        }) {
            HStack {
                Image(systemName: "chevron.left")
                    .foregroundColor(.black)
            }
        }
    }
}
