//
//  EmptyStateView.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import SwiftUI

/**
Common Component to show "Error" or "No-data" View
 */

struct EmptyStateView: View {
    let title: String
    
    var body: some View {
        VStack (alignment: .center, spacing: 0) {
            Text(title)
                .font(.nycDisplayFont(size: 24))
                .opacity(Color.solidFontOpacity)
                .padding(.bottom, 8)
        }
        .padding(EdgeInsets(top: 16, leading: 16, bottom: 16, trailing: 16))
    }
}
