//
//  ListItemView.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 11/22/21.
//

import Foundation
import SwiftUI

struct NavigationLinkStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(configuration.isPressed ? Color.black.opacity(0.16) : Color.clear)
    }
}

/**
Common Component to show row(or list item) in SchoolList & SchoolDetails View
 */
struct ListItemView<Control: View>: View {
    let title: String
    let titleWeight: Font.Weight
    let description: String?
    let hasDivider: Bool
    let control: Control
    
    private let defaultSpacing: CGFloat = 16.0
    
    init(title: String, titleWeight: Font.Weight = .semibold, description: String? = nil, hasDivider: Bool = true, @ViewBuilder control: @escaping () -> Control) {
        self.title = title
        self.titleWeight = titleWeight
        self.description = description
        self.hasDivider = hasDivider
        self.control = control()
    }
    
    init(title: String, description: String? = nil, hasDivider: Bool = true) where Control == EmptyView  {
        self.init(title: title, description: description, hasDivider: hasDivider) {
            EmptyView()
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            Spacer().frame(height: defaultSpacing)
            HStack(spacing: 0) {
                Text(title)
                    .font(.nycFont(weight: titleWeight, size: defaultSpacing))
                    .opacity(Color.solidFontOpacity)
                    .padding(.leading, defaultSpacing)
                
                Spacer()
                
                if let description = description {
                    Text(description)
                        .font(.nycFont(weight: .regular, size: 14.0))
                        .opacity(Color.fadedFontOpacity)
                        .padding(.trailing, defaultSpacing)
                }
                
                control.padding(.trailing, defaultSpacing)
            }
            Spacer().frame(height: defaultSpacing)
            if hasDivider {
                Divider()
                    .background(Color.black.opacity(Color.darkButtonPressedBackgroundOpacity))
                    .padding(.leading, defaultSpacing)
            }
        }
    }
}

