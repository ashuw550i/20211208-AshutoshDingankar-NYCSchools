//
//  CardView.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import SwiftUI

struct CardView<Content: View>: View {
    private let content: Content
    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.black.opacity(0.16), lineWidth: 1.0)
                            .background(RoundedRectangle(cornerRadius: 12)
                                            .fill(Color.white))
            content
        }
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView(content: {})
    }
}
