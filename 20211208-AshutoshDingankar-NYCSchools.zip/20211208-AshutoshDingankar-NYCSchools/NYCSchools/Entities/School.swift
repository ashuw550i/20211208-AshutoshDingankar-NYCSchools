//
//  School.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/2/21.
//

import Foundation

public struct School: Codable, Hashable {
    var dbn: String?
    var school_name: String?
    var phone_number: String?
    var fax_number: String?
    var school_email: String?
    var location: String?
    var total_students: String?
    var website: String?
}

extension School {
    var name: String {
        school_name ?? ""
    }
    
    var phone: String? {
        phone_number
    }
    
    var fax: String? {
        fax_number
    }
    
    var email: String? {
        school_email
    }
    
    var address: String? {
        //Removing Lat & Long info from the adress
        if let latLong = location?.slice(from: "(", to: ")") {
            return location?.replacingOccurrences(of: "(" + latLong + ")", with: "")
        }
        
        return location
    }
    
    var totalStudents: String? {
        total_students
    }
}
