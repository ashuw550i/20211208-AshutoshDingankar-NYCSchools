//
//  SATScore.swift
//  NYCSchools
//
//  Created by Ashutosh Dingankar on 12/7/21.
//

import Foundation

public struct SATScores: Codable, Hashable {
    var dbn: String?
    var school_name: String?
    var num_of_sat_test_takers: String?
    var sat_critical_reading_avg_score: String?
    var sat_math_avg_score: String?
    var sat_writing_avg_score: String?
}

public struct SATResult {
    //HashMap=> key=dbn & value= SATScores i.e. {dbn: SATScores}
    var result: [String: SATScores]?
}

extension SATResult {
    func getMathScore(school dbn: String) -> String? {
        return result?[dbn]?.sat_math_avg_score
    }
    
    func getReadingScore(school dbn: String) -> String? {
        return result?[dbn]?.sat_critical_reading_avg_score
    }
    
    func getWritingScore(school dbn: String) -> String? {
        return result?[dbn]?.sat_writing_avg_score
    }
}
